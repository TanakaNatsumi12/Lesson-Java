<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<%@include file="../header.html" %>

<%@ page import="java.util.Date" %>

<p>Hello!</p>
<p>こんにちは！</p>

<p><%=new java.util.Date() %></p>

<%@include file="../footer.html" %>