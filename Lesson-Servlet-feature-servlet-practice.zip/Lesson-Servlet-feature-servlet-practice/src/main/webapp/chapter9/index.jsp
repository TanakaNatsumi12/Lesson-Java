<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body>

<form action="basic2" method="post">
	
	<p>名前を入力してください。</p>
		<input type="text" name="user" >
	<p>年齢を入力してください。</p>
		<input type="text" name="age" >
		<input type="submit" value="送信" >
		
</form>



</body>
</html>